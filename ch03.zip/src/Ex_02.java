
public class Ex_02 {

	public static void main(String[] args) {
		int i=5, j=0;
		
		j=i++;
		System.out.println("j=j++ ���� ��, i="+i+",j="+j);
		
		i=5;
		j=0;
		
		j=++i;
		System.out.println("j=j++ ���� ��, i="+i+",j="+j);
	}

}
