
public class Ex_01 {

	public static void main(String[] args) {
		int i=5;
		i++;
		System.out.println(i);
		
		i=5;
		++i;
		System.out.println(i);
	}

}
