
public class Ex_07 {

	public static void main(String[] args) {
		int a=1000000;
		int b=2000000;
		long c=(long)a*b;
		
		System.out.println(c);
	}

}
